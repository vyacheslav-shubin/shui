# Прошивка SHUI. Версия для ознакомления и тестирования

## Плагин для слайсеров
**Текущая версия**: https://github.com/ipcn/shui-slicers-plugin/releases/

Поддерживается и развивается Иваном Поповым. (https://github.com/ipcn)

---
# SHUI firmware. Test only

## Plugin for slicers
**Current version**: https://github.com/ipcn/shui-slicers-plugin/releases/

Maintained and developed by Ivan Popov. (https://github.com/ipcn)